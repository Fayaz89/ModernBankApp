package com.pack.model;

import lombok.Data;

@Data
public class Login {

	private String email;
	private String password;
}
